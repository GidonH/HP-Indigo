import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-press-instalation',
  templateUrl: './press-instalation.component.html',
  styleUrls: ['./press-instalation.component.scss']
})
export class PressInstalationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
