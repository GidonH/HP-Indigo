export class MenuItems {

    items: string[] = [];

    constructor(items: string[]){
        this.items = items;
    }

}
